var mongoose = require('mongoose');

module.exports = mongoose.model('Order', {
    date: {
        type: Number,
        default: function () {
            return new Date().getTime()
        }
    },
    order: {
        type: Array,
        default: []
    },
    contacts: {
        type: Object,
        default: null
    },
    status: {
        type: Boolean,
        default: false
    }
});